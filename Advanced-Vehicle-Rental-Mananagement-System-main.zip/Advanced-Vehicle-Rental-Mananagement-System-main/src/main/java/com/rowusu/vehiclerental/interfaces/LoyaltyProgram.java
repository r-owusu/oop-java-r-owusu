package com.rowusu.vehiclerental.interfaces;

public interface LoyaltyProgram {
    int getLoyaltyPoints();
    void addLoyaltyPoints(int points);
    String getLoyaltyStatus();
}
