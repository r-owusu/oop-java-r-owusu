package com.rowusu.vehiclerental.exceptions;

public class CustomerNotEligible extends Exception {
    public CustomerNotEligible(String message) {
        super(message);
    }
}