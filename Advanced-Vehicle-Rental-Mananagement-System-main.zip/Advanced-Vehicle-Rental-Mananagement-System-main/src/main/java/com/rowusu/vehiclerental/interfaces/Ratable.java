package com.rowusu.vehiclerental.interfaces;

public interface Ratable {
    void addRating(int rating);
    double getAverageRating();
}

