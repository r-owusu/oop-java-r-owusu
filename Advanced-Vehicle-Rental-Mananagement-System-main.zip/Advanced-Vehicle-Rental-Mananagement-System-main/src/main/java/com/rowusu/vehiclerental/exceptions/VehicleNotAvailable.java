package com.rowusu.vehiclerental.exceptions;

public class VehicleNotAvailable extends Exception {
  public VehicleNotAvailable(String message) {
    super(message);
  }
}

