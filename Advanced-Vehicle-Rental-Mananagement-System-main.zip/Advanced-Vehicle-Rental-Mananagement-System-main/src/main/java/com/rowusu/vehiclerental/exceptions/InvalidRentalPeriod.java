package com.rowusu.vehiclerental.exceptions;

public class InvalidRentalPeriod extends Exception {
  public InvalidRentalPeriod(String message) {
    super(message);
  }
}

