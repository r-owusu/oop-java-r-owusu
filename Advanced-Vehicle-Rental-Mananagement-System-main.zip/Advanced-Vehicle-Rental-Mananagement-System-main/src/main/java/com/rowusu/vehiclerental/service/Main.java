package com.rowusu.vehiclerental.service;

public class Main {
}
